import { Sparkles } from 'lucide-react'
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function EmptyPosts() {
  return (
    <div className="flex flex-col items-center justify-center space-y-6 p-8 text-center">
      <div className="relative w-full max-w-md">
        <div className="absolute -right-4 -top-4 h-32 w-32 rotate-12 rounded-lg bg-muted/50" />
        <div className="relative overflow-hidden rounded-lg border bg-background p-4">
          <div className="flex items-center space-x-2">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-[#1DA1F2]" fill="currentColor">
              <path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z" />
            </svg>
            <span className="text-sm font-semibold">Twitter Post</span>
          </div>
          <div className="mt-4">
            <Image
              src="/placeholder.svg?height=400&width=400"
              alt="Example post"
              width={400}
              height={400}
              className="rounded-lg"
            />
          </div>
        </div>
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">Create your first post</h2>
        <p className="text-muted-foreground">
          Easy to get followers when they are most engaged! Design posts and schedule when to post.
        </p>
      </div>
      <ul className="space-y-2 text-sm text-muted-foreground">
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Choose from different post variations, including general
        </li>
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Determine posting schedule according to you
        </li>
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Use pre-designed templates to get started quickly
        </li>
      </ul>
      <div className="flex space-x-4">
        <Button className="space-x-2">
          <Sparkles className="h-4 w-4" />
          <span>Create with AI</span>
        </Button>
        <Button variant="outline">Create</Button>
      </div>
    </div>
  )
}

