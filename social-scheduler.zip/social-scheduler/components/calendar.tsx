"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface CalendarProps {
  className?: string
}

export function Calendar({ className }: CalendarProps) {
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
  const currentDate = new Date()
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
  const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)
  
  const daysInMonth = Array.from({ length: lastDayOfMonth.getDate() }, (_, i) => i + 1)
  
  return (
    <Card className={cn("p-4", className)}>
      <div className="grid grid-cols-7 gap-4">
        {days.map((day) => (
          <div
            key={day}
            className="text-sm font-medium text-muted-foreground text-center p-2"
          >
            {day}
          </div>
        ))}
        {daysInMonth.map((day) => (
          <div
            key={day}
            className={cn(
              "min-h-[100px] p-2 border rounded-lg",
              currentDate.getDate() === day && "bg-muted"
            )}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm">{day}</span>
              <Button variant="ghost" size="icon" className="h-6 w-6">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}

