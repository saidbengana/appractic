import Link from "next/link"
import { useState } from "react"
import { Calendar, BarChart2, Settings, HelpCircle, Box, Zap, Share2, CreditCard, Image, ChevronDown, ChevronRight } from 'lucide-react'
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import NextImage from "next/image"

interface SidebarItem {
  title: string
  icon: React.ComponentType<{ className?: string }>
  href: string
  isNew?: boolean
  children?: { title: string; href: string }[]
}

const headerItems: SidebarItem[] = [
  {
    title: "Planner",
    icon: Calendar,
    href: "/planner",
    children: [
      { title: "Posts", href: "/posts" },
      { title: "Calendar", href: "/planner/calendar" },
    ],
  },
  { title: "Socials", icon: Share2, href: "/socials" },
  { title: "Automations", icon: Zap, href: "/automations" },
  { title: "Analytics", icon: BarChart2, href: "/analytics" },
];

const footerItems: SidebarItem[] = [
  { title: "Assets", icon: Image, href: "/assets", isNew: true },
  { title: "Integrations", icon: Box, href: "/integrations" },
  { title: "Settings", icon: Settings, href: "/settings" },
  { title: "Billing & Usage", icon: CreditCard, href: "/billing" },
  { title: "Help", icon: HelpCircle, href: "/help" },
];

function SidebarItem({ item, isPlannerExpanded, setIsPlannerExpanded }: { item: SidebarItem; isPlannerExpanded?: boolean; setIsPlannerExpanded?: (expanded: boolean) => void }) {
  return (
    <div>
      {item.children ? (
        <div>
          <Button
            variant="ghost"
            onClick={() => setIsPlannerExpanded?.(!isPlannerExpanded)}
            className={cn(
              "w-full justify-start py-1.5 px-3 text-gray-600 hover:bg-gray-100/80",
              "mb-1 text-[14px] font-medium",
              item.title === "Planner" && "bg-gray-100"
            )}
          >
            <item.icon className="mr-3 h-5 w-5 text-gray-500" />
            <span className="flex-1 text-left">{item.title}</span>
            <ChevronDown 
              className={cn(
                "h-4 w-4 text-gray-400 transition-transform duration-200",
                !isPlannerExpanded && "-rotate-90"
              )} 
            />
          </Button>
          {isPlannerExpanded && (
            <div className="ml-10 space-y-1">
              {item.children.map((child) => (
                <Link key={child.title} href={child.href}>
                  <Button
                    variant="ghost"
                    className="w-full justify-start py-1.5 px-3 text-[14px] font-medium text-gray-600 hover:bg-gray-100/80"
                  >
                    {child.title}
                  </Button>
                </Link>
              ))}
            </div>
          )}
        </div>
      ) : (
        <Link href={item.href}>
          <Button
            variant="ghost"
            className="w-full justify-start py-1.5 px-3 text-[14px] font-medium text-gray-600 hover:bg-gray-100/80"
          >
            <item.icon className="mr-3 h-5 w-5 text-gray-500" />
            <span className="flex-1 text-left">{item.title}</span>
            {item.isNew && (
              <span className="ml-2 rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
                NEW
              </span>
            )}
          </Button>
        </Link>
      )}
    </div>
  )
}

export function Sidebar() {
  const [isPlannerExpanded, setIsPlannerExpanded] = useState(true)

  return (
    <div className="flex w-64 flex-col bg-white">
      <div className="p-6 flex items-start gap-3">
        <div className="rounded-xl bg-gradient-to-br from-pink-300 to-pink-400 p-2">
          <NextImage
            src="/placeholder.svg?height=32&width=32"
            alt="Personal"
            width={32}
            height={32}
            className="rounded-lg"
          />
        </div>
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <span className="text-[15px] font-medium text-gray-900">Personal</span>
            <ChevronRight className="h-4 w-4 text-gray-400" />
          </div>
          <span className="text-[13px] text-gray-500">Owner</span>
        </div>
      </div>
      <div className="px-3 mb-4">
        {headerItems.map((item, index) => (
          <SidebarItem key={index} item={item} isPlannerExpanded={isPlannerExpanded} setIsPlannerExpanded={setIsPlannerExpanded} />
        ))}
      </div>
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-0.5">
          {footerItems.map((item, index) => (
            <SidebarItem key={index} item={item} />
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

