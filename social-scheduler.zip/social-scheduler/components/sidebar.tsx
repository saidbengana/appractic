import Link from "next/link"
import { useState } from "react"
import { Calendar, BarChart2, Settings, HelpCircle, Box, Zap, Share2, CreditCard, Image, ChevronDown, ChevronRight } from 'lucide-react'
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import Image from "next/image"

interface SidebarItem {
  title?: string
  icon?: React.ComponentType<{ className?: string }>
  href?: string
  isNew?: boolean
  children?: { title: string; href: string }[]
  isSeparator?: boolean
}

const sidebarItems: SidebarItem[] = [
  {
    title: "Planner",
    icon: Calendar,
    href: "/planner",
    children: [
      { title: "Posts", href: "/posts" },
      { title: "Calendar", href: "/planner/calendar" },
    ],
  },
  { title: "Socials", icon: Share2, href: "/socials" },
  { title: "Automations", icon: Zap, href: "/automations" },
  { title: "Analytics", icon: BarChart2, href: "/analytics" },
  { isSeparator: true },
  { title: "Assets", icon: Image, href: "/assets", isNew: true },
  { title: "Integrations", icon: Box, href: "/integrations" },
  { title: "Settings", icon: Settings, href: "/settings" },
  { title: "Billing & Usage", icon: CreditCard, href: "/billing" },
  { title: "Help", icon: HelpCircle, href: "/help" },
]

export function Sidebar() {
  const [isPlannerExpanded, setIsPlannerExpanded] = useState(true)

  return (
    <div className="flex w-64 flex-col bg-white">
      <div className="p-4 flex items-start gap-3">
        <div className="rounded-xl bg-gradient-to-br from-pink-300 to-pink-400 p-2">
          <Image
            src="/placeholder.svg?height=32&width=32"
            alt="Personal"
            width={32}
            height={32}
            className="rounded-lg"
          />
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-base font-medium text-gray-900">Personal</span>
            <ChevronRight className="h-4 w-4 text-gray-400" />
          </div>
          <span className="text-sm text-gray-500">Owner</span>
        </div>
      </div>
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-1">
          {sidebarItems.map((item) => (
            <div key={item.title || 'separator'}>
              {item.isSeparator ? (
                <div className="my-4" />
              ) : (
                <div>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      if (item.children) {
                        setIsPlannerExpanded(!isPlannerExpanded)
                      }
                    }}
                    className={cn(
                      "w-full justify-start px-3 py-2 text-gray-600 hover:bg-gray-100/80",
                      item.children && "mb-1",
                      item.title === "Planner" && "bg-gray-100"
                    )}
                  >
                    <item.icon className="mr-3 h-5 w-5 text-gray-500" />
                    <span className="flex-1 text-left text-sm font-medium">{item.title}</span>
                    {item.children && (
                      <ChevronDown className={cn(
                        "h-4 w-4 text-gray-400 transition-transform",
                        !isPlannerExpanded && "-rotate-90"
                      )} />
                    )}
                    {item.isNew && (
                      <span className="ml-2 rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
                        NEW
                      </span>
                    )}
                  </Button>
                  {item.children && isPlannerExpanded && (
                    <div className="ml-10 space-y-1">
                      {item.children.map((child) => (
                        <Link key={child.title} href={child.href}>
                          <Button
                            variant="ghost"
                            className="w-full justify-start px-3 py-1.5 text-sm font-medium text-gray-600 hover:bg-gray-100/80"
                          >
                            {child.title}
                          </Button>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

