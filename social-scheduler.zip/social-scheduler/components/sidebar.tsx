import Link from "next/link"
import { useState } from "react"
import { Calendar, BarChart2, Settings, HelpCircle, Box, Zap, Share2, CreditCard, Image, ChevronDown, ChevronRight } from 'lucide-react'
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface SidebarItem {
  title: string
  icon: React.ComponentType<{ className?: string }>
  href: string
  isNew?: boolean
  children?: { title: string; href: string }[]
}

const sidebarItems: SidebarItem[] = [
  {
    title: "Planner",
    icon: Calendar,
    href: "/planner",
    children: [
      { title: "Calendar", href: "/planner/calendar" },
      { title: "Socials", href: "/socials" },
    ],
  },
  { title: "Socials", icon: Share2, href: "/socials" },
  { title: "Automations", icon: Zap, href: "/automations" },
  { title: "Analytics", icon: BarChart2, href: "/analytics" },
  { title: "Assets", icon: Image, href: "/assets", isNew: true },
  { title: "Integrations", icon: Box, href: "/integrations" },
  { title: "Settings", icon: Settings, href: "/settings" },
  { title: "Billing & Usage", icon: CreditCard, href: "/billing" },
  { title: "Help", icon: HelpCircle, href: "/help" },
]

export function Sidebar() {
  const [isPlannerExpanded, setIsPlannerExpanded] = useState(false)

  return (
    <div className="flex w-64 flex-col border-r bg-background">
      <div className="p-4">
        <div className="flex h-12 items-center">
          {/* Logo would go here */}
          <span className="text-lg font-semibold">Social Scheduler</span>
        </div>
      </div>
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-4">
          {sidebarItems.map((item) => (
            <div key={item.title}>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start",
                  item.children && "mb-2"
                )}
                onClick={() => {
                  if (item.children) {
                    setIsPlannerExpanded(!isPlannerExpanded)
                  } else {
                    // Handle navigation for items without children
                  }
                }}
              >
                <item.icon className="mr-2 h-4 w-4" />
                <span className="flex-1 text-left">{item.title}</span>
                {item.children && (
                  isPlannerExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
                )}
                {item.isNew && (
                  <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">
                    NEW
                  </span>
                )}
              </Button>
              {item.children && isPlannerExpanded && (
                <div className="ml-4 mt-2 space-y-2">
                  {item.children.map((child) => (
                    <Link key={child.title} href={child.href}>
                      <Button
                        variant="ghost"
                        className="w-full justify-start"
                      >
                        {child.title}
                      </Button>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

