import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

interface SocialPlatformCardProps {
  name: string
  description: string
  icon: string
  isComingSoon?: boolean
  onClick?: () => void
}

export function SocialPlatformCard({
  name,
  description,
  icon,
  isComingSoon = false,
  onClick
}: SocialPlatformCardProps) {
  return (
    <Card className="flex flex-col">
      <CardHeader className="flex-row items-center gap-4">
        <div className="w-12 h-12 relative flex-shrink-0">
          <Image
            src={icon}
            alt={name}
            fill
            className="object-contain"
          />
        </div>
        <div>
          <CardTitle className="text-xl">{name}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col flex-1">
        <CardDescription className="flex-1">
          {description}
        </CardDescription>
        {isComingSoon ? (
          <div className="mt-4">
            <span className="text-sm text-muted-foreground">Coming soon</span>
          </div>
        ) : (
          <Button 
            onClick={onClick} 
            className="mt-4"
            variant="outline"
          >
            Connect
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

