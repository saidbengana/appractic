import Link from "next/link"
import { Sidebar } from "./sidebar"
import { Header } from "./header"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col h-screen">
      <div className="bg-background border-b">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="social-media">
            <TabsList>
              <TabsTrigger value="social-media" asChild>
                <Link href="/">Social media</Link>
              </TabsTrigger>
              <TabsTrigger value="copywriting" asChild>
                <Link href="/copywriting">Copywriting</Link>
              </TabsTrigger>
              <TabsTrigger value="ai-agents">AI agents</TabsTrigger>
              <TabsTrigger value="hire-professionals">Hire professionals</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </div>
  )
}

