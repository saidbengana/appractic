import { CopywritingSidebar } from "./copywriting-sidebar"
import { Header } from "./header"

export function CopywritingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen">
      <CopywritingSidebar />
      <div className="flex flex-col flex-1">
        <Header />
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  )
}

