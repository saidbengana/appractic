import { CopywritingSidebar } from "./copywriting-sidebar"

export function CopywritingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen">
      <CopywritingSidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  )
}

