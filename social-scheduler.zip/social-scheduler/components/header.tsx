import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <div className="flex items-center justify-between border-b px-6 py-4">
      <h1 className="text-2xl font-semibold">Copywriting</h1>
      <Button variant="default">New</Button>
    </div>
  )
}

