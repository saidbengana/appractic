import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react'

export function Header() {
  return (
    <div className="border-b">
      <div className="flex h-16 items-center px-4">
        <Tabs defaultValue="social-media" className="mr-auto">
          <TabsList>
            <TabsTrigger value="social-media">Social media</TabsTrigger>
            <TabsTrigger value="copywriting">Copywriting</TabsTrigger>
            <TabsTrigger value="ai-agents">AI agents</TabsTrigger>
            <TabsTrigger value="hire">Hire professionals</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="ml-auto flex items-center space-x-4">
          <Select defaultValue="November, 2024">
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="November, 2024">November, 2024</SelectItem>
              <SelectItem value="December, 2024">December, 2024</SelectItem>
              <SelectItem value="January, 2025">January, 2025</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm">Today</Button>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">List</Button>
            <Button variant="outline" size="sm">Month</Button>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" /> New
          </Button>
        </div>
      </div>
    </div>
  )
}

