import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"

interface SocialProfile {
  name: string
  platform: string
  logo: string
  timeAgo: string
}

const exampleProfiles: SocialProfile[] = [
  { name: "Apple", platform: "facebook", logo: "/placeholder.svg?height=40&width=40", timeAgo: "2 weeks ago" },
  { name: "McDonald's", platform: "facebook", logo: "/placeholder.svg?height=40&width=40", timeAgo: "1 month ago" },
  { name: "Nike", platform: "facebook", logo: "/placeholder.svg?height=40&width=40", timeAgo: "2 months ago" },
]

export function EmptySocials() {
  return (
    <div className="flex flex-col items-center justify-center space-y-6 p-8 text-center">
      <div className="relative w-full max-w-2xl">
        <Card className="overflow-hidden bg-background p-6">
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm text-muted-foreground">Profiles</div>
            <Button size="sm" variant="outline">Connect profile</Button>
          </div>
          <div className="space-y-4">
            {exampleProfiles.map((profile, index) => (
              <div key={index} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                <div className="flex items-center space-x-4">
                  <Image
                    src={profile.logo}
                    alt={profile.name}
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                  <div>
                    <div className="font-medium">{profile.name}</div>
                    <div className="text-sm text-muted-foreground">{profile.timeAgo}</div>
                  </div>
                </div>
                <Button variant="ghost" size="sm">•••</Button>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">Connect your social profiles</h2>
        <p className="text-muted-foreground">
          Connecting socials just got easier, thanks to our integrations made just for you.
        </p>
      </div>
      <ul className="space-y-2 text-sm text-muted-foreground">
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Connect profiles that complement your needs
        </li>
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Access profiles anywhere on the planner
        </li>
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Publish to many at once to save time
        </li>
      </ul>
      <Button size="lg">Connect</Button>
    </div>
  )
}

