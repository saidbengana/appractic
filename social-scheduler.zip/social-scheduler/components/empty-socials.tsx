import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

interface SocialProfile {
  name: string
  platform: string
  logo: string
  timeAgo: string
}

const exampleProfiles: SocialProfile[] = [
  { name: "Apple", platform: "facebook", logo: "/placeholder.svg?height=40&width=40", timeAgo: "2 weeks ago" },
  { name: "McDonald's", platform: "facebook", logo: "/placeholder.svg?height=40&width=40", timeAgo: "1 month ago" },
  { name: "Nike", platform: "facebook", logo: "/placeholder.svg?height=40&width=40", timeAgo: "2 months ago" },
]

export default function EmptySocials() {
  return (
    <div className="flex flex-col items-center justify-center space-y-6 p-8 text-center">
      <div className="relative w-full max-w-2xl">
        <Image
          src="/placeholder.svg?height=300&width=600"
          alt="Social profiles placeholder"
          width={600}
          height={300}
          className="w-full h-auto"
        />
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">Connect your social profiles</h2>
        <p className="text-muted-foreground">
          Connecting socials just got easier, thanks to our integrations made just for you.
        </p>
      </div>
      <ul className="space-y-2 text-sm text-muted-foreground">
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Connect profiles that complement your needs
        </li>
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Access profiles anywhere on the planner
        </li>
        <li className="flex items-center">
          <svg
            className="mr-2 h-4 w-4 text-primary"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
          Publish to many at once to save time
        </li>
      </ul>
      <Button asChild size="lg">
        <Link href="/socials/connect">Connect</Link>
      </Button>
    </div>
  )
}

