import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Pen, FileText, Zap, Image, Box, Settings, CreditCard, HelpCircle } from 'lucide-react'

const sidebarItems = [
  { name: "Copywriter", icon: Pen, href: "/copywriting" },
  { name: "Article Builder", icon: FileText, href: "/copywriting/article-builder" },
  { name: "Automations", icon: Zap, href: "/copywriting/automations" },
  { name: "Assets", icon: Image, href: "/copywriting/assets", isNew: true },
  { name: "Integrations", icon: Box, href: "/copywriting/integrations" },
  { name: "Settings", icon: Settings, href: "/copywriting/settings" },
  { name: "Billing & Usage", icon: CreditCard, href: "/copywriting/billing" },
  { name: "Help", icon: HelpCircle, href: "/copywriting/help" },
]

export function CopywritingSidebar() {
  return (
    <div className="flex w-64 flex-col border-r bg-background">
      <div className="p-4">
        <div className="flex h-12 items-center">
          <span className="text-lg font-semibold">Personal</span>
        </div>
        <p className="text-sm text-muted-foreground">Owner</p>
      </div>
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-4">
          {sidebarItems.map((item) => (
            <div key={item.name}>
              <Link href={item.href}>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  <span className="flex-1 text-left">{item.name}</span>
                  {item.isNew && (
                    <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">
                      NEW
                    </span>
                  )}
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

