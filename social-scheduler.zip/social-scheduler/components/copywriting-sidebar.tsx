import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Pen, FileText, Zap, Image, Box, Settings, CreditCard, HelpCircle } from 'lucide-react'

const sidebarItems = [
  { name: "Copywriter", icon: Pen, href: "/copywriting" },
  { name: "Article Builder", icon: FileText, href: "/copywriting/article-builder" },
  { name: "Automations", icon: Zap, href: "/copywriting/automations" },
  { name: "Assets", icon: Image, href: "/copywriting/assets", isNew: true },
  { name: "Integrations", icon: Box, href: "/copywriting/integrations" },
  { name: "Settings", icon: Settings, href: "/copywriting/settings" },
  { name: "Billing & Usage", icon: CreditCard, href: "/copywriting/billing" },
  { name: "Help", icon: HelpCircle, href: "/copywriting/help" },
]

export function CopywritingSidebar() {
  return (
    <div className="w-64 bg-gray-900 text-white">
      <div className="p-4">
        <h2 className="text-xl font-semibold">Personal</h2>
        <p className="text-sm text-gray-400">Owner</p>
      </div>
      <ScrollArea className="h-[calc(100vh-80px)]">
        <nav className="space-y-2 p-2">
          {sidebarItems.map((item) => (
            <Link key={item.name} href={item.href}>
              <Button
                variant="ghost"
                className="w-full justify-start text-white hover:bg-gray-800"
              >
                <item.icon className="mr-2 h-4 w-4" />
                {item.name}
                {item.isNew && (
                  <span className="ml-auto rounded-full bg-blue-500 px-2 py-0.5 text-xs">
                    NEW
                  </span>
                )}
              </Button>
            </Link>
          ))}
        </nav>
      </ScrollArea>
    </div>
  )
}

