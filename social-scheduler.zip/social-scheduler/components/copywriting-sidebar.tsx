import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Pen, FileText, Zap, Image, Box, Settings, CreditCard, HelpCircle, ChevronRight } from 'lucide-react'
import NextImage from "next/image"

interface SidebarItem {
  name: string
  icon: React.ComponentType<{ className?: string }>
  href: string
  isNew?: boolean
}

const sidebarItems: SidebarItem[] = [
  { name: "Copywriter", icon: Pen, href: "/copywriting" },
  { name: "Article Builder", icon: FileText, href: "/copywriting/article-builder" },
  { name: "Automations", icon: Zap, href: "/copywriting/automations" },
  { name: "Assets", icon: Image, href: "/copywriting/assets", isNew: true },
  { name: "Integrations", icon: Box, href: "/copywriting/integrations" },
  { name: "Settings", icon: Settings, href: "/copywriting/settings" },
  { name: "Billing & Usage", icon: CreditCard, href: "/copywriting/billing" },
  { name: "Help", icon: HelpCircle, href: "/copywriting/help" },
]

export function CopywritingSidebar() {
  return (
    <div className="flex w-64 flex-col bg-white">
      <div className="p-6 flex items-start gap-3">
        <div className="rounded-xl bg-gradient-to-br from-pink-300 to-pink-400 p-2">
          <NextImage
            src="/placeholder.svg?height=32&width=32"
            alt="Personal"
            width={32}
            height={32}
            className="rounded-lg"
          />
        </div>
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <span className="text-[15px] font-medium text-gray-900">Personal</span>
            <ChevronRight className="h-4 w-4 text-gray-400" />
          </div>
          <span className="text-[13px] text-gray-500">Owner</span>
        </div>
      </div>
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-0.5">
          {sidebarItems.map((item) => (
            <Link key={item.name} href={item.href}>
              <Button
                variant="ghost"
                className="w-full justify-start py-1.5 px-3 text-[14px] font-medium text-gray-600 hover:bg-gray-100/80"
              >
                <item.icon className="mr-3 h-5 w-5 text-gray-500" />
                <span className="flex-1 text-left">{item.name}</span>
                {item.isNew && (
                  <span className="ml-2 rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
                    NEW
                  </span>
                )}
              </Button>
            </Link>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

