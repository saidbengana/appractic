import Layout from "@/components/layout"
import EmptySocials from "@/components/empty-socials"
import { Button } from "@/components/ui/button"

export default function SocialsPage() {
  return (
    <Layout>
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between border-b px-6 py-4">
          <h1 className="text-2xl font-semibold">Socials</h1>
          <Button variant="default">Connect</Button>
        </div>
        <div className="flex-1">
          <EmptySocials />
        </div>
      </div>
    </Layout>
  )
}

