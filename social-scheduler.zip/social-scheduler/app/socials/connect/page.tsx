import { Layout } from "@/components/layout"
import { SocialPlatformCard } from "@/components/social-platform-card"

const socialPlatforms = [
  {
    name: "Facebook Page",
    description: "Schedule and analyse posts on Facebook Pages.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: false,
  },
  {
    name: "Instagram Business",
    description: "Schedule and analyse posts on Instagram Business profiles.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: false,
  },
  {
    name: "X (Twitter)",
    description: "Schedule and analyse posts on Twitter accounts.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: false,
  },
  {
    name: "LinkedIn",
    description: "Connect your LinkedIn Personal profiles or Company pages.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: false,
  },
  {
    name: "Pinterest",
    description: "Connect to schedule pins on your Pinterest profiles.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: false,
  },
  {
    name: "Threads",
    description: "Schedule and analyse posts on your Threads profiles.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
  {
    name: "Tiktok",
    description: "Schedule and analyse videos on your Tiktok accounts.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
  {
    name: "Google Business",
    description: "Schedule and analyse posts on your Google Business Profile.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
  {
    name: "Youtube Shorts",
    description: "Schedule and analyse Shorts on your Youtube channel.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
  {
    name: "Discord",
    description: "Schedule announcements on your Discord channels.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
  {
    name: "Telegram",
    description: "Schedule announcements on your Telegram channels.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
  {
    name: "Slack",
    description: "Schedule and analyse posts on Slack channels.",
    icon: "/placeholder.svg?height=48&width=48",
    isComingSoon: true,
  },
]

export default function ConnectPage() {
  return (
    <Layout>
      <div className="flex flex-col p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold tracking-tight">Connect social profiles</h1>
          <p className="text-muted-foreground mt-2">
            Connect your social network profiles here. Need help?{" "}
            <a href="#" className="text-primary hover:underline">
              Invite a teammate
            </a>{" "}
            to complete this step.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {socialPlatforms.map((platform) => (
            <SocialPlatformCard
              key={platform.name}
              name={platform.name}
              description={platform.description}
              icon={platform.icon}
              isComingSoon={platform.isComingSoon}
              onClick={() => console.log(`Connecting to ${platform.name}`)}
            />
          ))}
        </div>
      </div>
    </Layout>
  )
}

