import { Layout } from "@/components/layout"
import { Calendar } from "@/components/calendar"

export default function CalendarPage() {
  return (
    <Layout>
      <div className="p-6">
        <Calendar />
      </div>
    </Layout>
  )
}

