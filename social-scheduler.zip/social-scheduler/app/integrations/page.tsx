import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowUpRight } from 'lucide-react'
import Image from "next/image"

interface IntegrationCard {
  title: string
  description: string
  icon: string
  action: "Use" | "Hire"
  isNew?: boolean
}

const developerIntegrations: IntegrationCard[] = [
  {
    title: "API",
    description: "Our API makes it easy for developers to simply and smoothly integrate with other apps.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  },
  {
    title: "Embed",
    description: "Our embed widget lets you add social scheduling into your product with just a few lines of code. No API required.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  }
]

const ecommerceIntegrations: IntegrationCard[] = [
  {
    title: "Shopify",
    description: "Connect to import your Shopify products and generate posts.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  },
  {
    title: "WooCommerce",
    description: "Connect to import your WooCommerce products.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use",
    isNew: true
  },
  {
    title: "Etsy",
    description: "Connect to import your Etsy products and generate posts.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use",
    isNew: true
  },
  {
    title: "BigCommerce",
    description: "Connect to import your BigCommerce products.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  }
]

const cmsIntegrations: IntegrationCard[] = [
  {
    title: "Webflow",
    description: "Connect to post articles straight to Webflow CMS.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  },
  {
    title: "Wordpress",
    description: "Connect to post articles straight to Wordpress sites.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  }
]

const generalIntegrations: IntegrationCard[] = [
  {
    title: "Zapier",
    description: "Automate post creation with other flows and triggers.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  },
  {
    title: "Integrately",
    description: "Streamline post creation by integrating various workflows.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Use"
  },
  {
    title: "Fiverr",
    description: "Hire professionals and manage your content with expert help.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Hire"
  },
  {
    title: "Upwork",
    description: "Find professionals experienced in social media management or ads.",
    icon: "/placeholder.svg?height=48&width=48",
    action: "Hire",
    isNew: true
  }
]

function IntegrationSection({ 
  title, 
  description, 
  integrations 
}: { 
  title: string
  description: string
  integrations: IntegrationCard[]
}) {
  return (
    <section className="mb-12">
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-1">{title}</h2>
        <p className="text-muted-foreground text-sm">{description}</p>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {integrations.map((integration) => (
          <Card key={integration.title} className="flex flex-col">
            <CardHeader className="flex-row items-center gap-4">
              <div className="w-12 h-12 relative flex-shrink-0">
                <Image
                  src={integration.icon}
                  alt={integration.title}
                  fill
                  className="object-contain"
                />
              </div>
              <div className="flex items-center gap-2">
                <CardTitle className="text-xl">{integration.title}</CardTitle>
                {integration.isNew && (
                  <Badge variant="secondary" className="h-5 text-xs font-medium">
                    NEW
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="flex flex-col flex-1">
              <CardDescription className="flex-1 mb-4">
                {integration.description}
              </CardDescription>
              <Button 
                variant="outline" 
                className="w-fit"
                size="sm"
              >
                {integration.action}
                {integration.action === "Hire" && (
                  <ArrowUpRight className="ml-1 h-4 w-4" />
                )}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}

export default function IntegrationsPage() {
  return (
    <Layout>
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between border-b px-6 py-4">
          <h1 className="text-2xl font-semibold">Integrations</h1>
        </div>
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <IntegrationSection
              title="Developer"
              description="Use our in-house programming interfaces for your needs."
              integrations={developerIntegrations}
            />
            <IntegrationSection
              title="Ecommerce"
              description="Use our third-party ecommerce integrations. You can also find them in the 'Plugins' section of the post editor."
              integrations={ecommerceIntegrations}
            />
            <IntegrationSection
              title="CMS"
              description="Use our third-party CMS integrations."
              integrations={cmsIntegrations}
            />
            <IntegrationSection
              title="General"
              description="Use our third-party integrations."
              integrations={generalIntegrations}
            />
          </div>
        </div>
      </div>
    </Layout>
  )
}

