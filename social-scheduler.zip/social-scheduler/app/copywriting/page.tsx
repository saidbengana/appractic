import { CopywritingLayout } from "@/components/copywriting-layout"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Search } from 'lucide-react'
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

const categories = [
  "Ads", "Blog", "Business", "Social media", "Frameworks", "Ecommerce",
  "Fun", "Video", "Personal", "Marketing"
]

const templates = [
  { name: "Google ad", description: "Enabling you become a Google Ad Master", icon: "G" },
  { name: "Facebook ad", description: "Optimised to get you maximum visibility", icon: "f" },
  { name: "YouTube Description", description: "Create an engaging script for your audience", icon: "Y" },
  { name: "Tweet Ideas", description: "Engage your followers with retweetable content", icon: "X" },
  { name: "Amazon Description", description: "Make your product stand out from the rest", icon: "a" },
  { name: "Instagram Ad Copy", description: "Make them stop scrolling", icon: "I" },
  { name: "Linkedin Ad Copy", description: "Reach more businesses with better copy", icon: "in" },
  { name: "Quora Responses", description: "Give the most compelling answers", icon: "Q" },
  // Add more templates as needed
]

export default function CopywritingPage() {
  return (
    <>
      <div className="w-full bg-background border-b">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="copywriting">
            <TabsList>
              <TabsTrigger value="social-media" asChild>
                <Link href="/">Social media</Link>
              </TabsTrigger>
              <TabsTrigger value="copywriting" asChild>
                <Link href="/copywriting">Copywriting</Link>
              </TabsTrigger>
              <TabsTrigger value="ai-agents">AI agents</TabsTrigger>
              <TabsTrigger value="hire-professionals">Hire professionals</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
      <CopywritingLayout>
        <div className="p-6">
          <h1 className="text-3xl font-bold mb-6">All templates</h1>
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-2">Pick a template</h2>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input className="pl-10" placeholder="Search for templates" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Categories</CardTitle>
                <CardDescription>Choose from different templates according to your needs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {categories.map((category) => (
                    <Button key={category} variant="outline" className="justify-start">
                      {category}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
            {templates.map((template) => (
              <Card key={template.name}>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                      {template.icon}
                    </div>
                    <CardTitle>{template.name}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>{template.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </CopywritingLayout>
    </>
  )
}

