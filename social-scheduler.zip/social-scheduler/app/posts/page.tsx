import { Layout } from "@/components/layout"

export default function PostsPage() {
  return (
    <Layout>
      <div className="p-6">
        {/* Content for the posts page will go here */}
      </div>
    </Layout>
  )
}

