import { Layout } from "@/components/layout"
import { EmptyPosts } from "@/components/empty-posts"
import { PostsHeader } from "@/components/posts-header"

export default function PostsPage() {
  return (
    <Layout>
      <div className="flex flex-col h-full">
        <PostsHeader />
        <div className="flex-1">
          <EmptyPosts />
        </div>
      </div>
    </Layout>
  )
}

