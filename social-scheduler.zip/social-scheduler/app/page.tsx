import { Layout } from "@/components/layout"

export default function Page() {
  return (
    <Layout>
      <div className="p-6">
        {/* Content for the main page */}
      </div>
    </Layout>
  )
}

